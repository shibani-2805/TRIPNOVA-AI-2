# TripNova – Explore More, Travel Smarter

TripNova is a trip-planning website built with **Python Flask**, **SQLite**, **HTML, CSS and JavaScript**.
You choose destinations, dates, travellers, budget and interests. TripNova builds a day-by-day plan with
attractions, hotels (with links), meals, weather, daily costs and a total cost in the right currencies.

It is a conversion of the console program `AITravelPlanner` into a full website. Your original
destination, activity, restaurant, hotel and travel-tip data is kept exactly as written.

---

## 1. What is rule-based and what is AI?

Nothing is hidden. This is exactly how each feature works:

| Feature | How it works | Needs an API key? |
|---|---|---|
| Itinerary (days, activities, attractions, meals) | **Rule-based Python.** Days are split across destinations, items are picked from your data tables using a seeded random generator. | No |
| Hotel recommendations and links | **Rule-based.** Looked up from your hotel table by destination and budget. | No |
| Daily and total cost | **Rule-based maths.** Daily budget + activity prices, times travellers. | No |
| Currency conversion | **Live exchange rates** from `open.er-api.com` when reachable, otherwise **approximate fixed rates** (the page says which was used). Not AI. | No |
| Weather | **Live forecast** from Open-Meteo for dates up to 15 days ahead. Other dates show a **seasonal estimate** that is clearly labelled "not a forecast". Random weather was removed. Not AI. | No |
| Login, register, saved trips | Flask + SQLite. Passwords are hashed. | No |
| **AI trip brief** (optional) | **Real AI.** Calls the Anthropic API to write a short friendly summary and packing list from your finished plan. It cannot change the itinerary or costs. | **Yes** – `ANTHROPIC_API_KEY` |

If you do not set an API key, the AI button simply does not appear. The rest of the website works fully.
The project is not "AI" in the machine-learning sense unless you switch on the optional AI brief,
so describe it honestly in your report as a **rule-based planner with an optional AI feature**.

---

## 2. Project structure

```
tripnova/
├── app.py                 Flask server: routes, login, database, optional AI call
├── travel_planner.py      Your AITravelPlanner class (data + planning logic)
├── requirements.txt       Python packages to install
├── Procfile               Start command for hosts that use a Procfile
├── .gitignore             Files Git must NOT upload (secrets, database)
├── .env.example           Template for your secret settings
├── README.md              This file
├── templates/
│   └── index.html         The web page (Flask serves it)
└── static/
    ├── style.css          Design (blue and white theme, responsive)
    └── script.js          Page behaviour, talks to the server
```

Why are `index.html`, `style.css` and `script.js` in folders? Flask looks for pages in `templates/`
and for CSS/JS in `static/`. Those exact names are used everywhere in the code.

---

## 3. Run it on your computer

You need **Python 3.9 or newer**. Check with `python --version` (on macOS/Linux you may need `python3`).

**Step 1 – Open a terminal in the project folder**
- Windows: open the folder, click the address bar, type `cmd`, press Enter.
- macOS/Linux: open Terminal and `cd` into the folder.

**Step 2 – Create a virtual environment** (a private box for this project's packages)
```
python -m venv venv
```

**Step 3 – Activate it**
- Windows: `venv\Scripts\activate`
- macOS/Linux: `source venv/bin/activate`

You will see `(venv)` at the start of the line.

**Step 4 – Install the packages**
```
pip install -r requirements.txt
```

**Step 5 – Create your settings file**
- Copy `.env.example` and name the copy `.env`
  (Windows: `copy .env.example .env` — macOS/Linux: `cp .env.example .env`).
- Open `.env` and change `SECRET_KEY` to a long random text. Make one with:
  ```
  python -c "import secrets; print(secrets.token_hex(32))"
  ```

**Step 6 – Start the website**
```
python app.py
```

**Step 7 – Open it** in your browser: <http://127.0.0.1:5000>

Press `Ctrl + C` in the terminal to stop it. The database file `tripnova.db` is created automatically.

### Test the planner without the website (optional)
```
python travel_planner.py
```
This prints a sample plan as JSON.

---

## 4. Settings (environment variables)

Set these in `.env` on your computer, or in your hosting dashboard when deployed.

| Name | Required? | Meaning |
|---|---|---|
| `SECRET_KEY` | **Yes when deployed** | Long random text that protects login sessions. Keep it private. |
| `COOKIE_SECURE` | Recommended online | Set `true` when the site uses HTTPS (Render does). |
| `DATABASE_PATH` | No | Where the SQLite file is stored. Default: `tripnova.db` next to `app.py`. |
| `USE_LIVE_WEATHER` | No | `true` (default) or `false`. Uses the free Open-Meteo service. No key needed. |
| `USE_LIVE_RATES` | No | `true` (default) or `false`. Uses the free exchange-rate service. No key needed. |
| `ANTHROPIC_API_KEY` | No | Turns on the optional **AI trip brief**. Get a key at <https://console.anthropic.com/>. Usage is billed by Anthropic. |
| `ANTHROPIC_MODEL` | No | Model name for the AI brief. Default `claude-sonnet-5-5`. |

**Never** write a real key inside `app.py` or upload `.env` to GitHub. The `.gitignore` file already blocks `.env`.

---

## 5. Using the website

1. **Home** – read about TripNova, browse destinations, press **Get Started**.
2. **Plan Trip** – pick destinations, start date, days, travellers, budget, activity types, number of activities and the currency for the total. Press **Generate Trip**.
3. **Results** – see the summary, attractions, hotel links, the day-wise plan (morning, afternoon, evening, three meals), weather, daily costs, total cost and tips. You can **Print / PDF**, make a **New version**, or **Edit inputs**.
4. **Sign up / Log in** – needed only to **Save trip**. Saved plans appear in **My Trips**.

Rules checked on both the page and the server: 1 to 30 days, 1 to 20 travellers, at least one destination (no duplicates), at least as many days as destinations, a valid date that is not in the past, a valid budget, at least one activity type, and an activity count that does not exceed what your chosen types offer.

---

## 6. How the code fits together (simple version)

1. You fill in the form in `index.html`. `script.js` sends the values to the server (`POST /api/generate`).
2. `app.py` receives them and calls `AITravelPlanner.validate_trip_request()` in `travel_planner.py` to check them.
3. `AITravelPlanner.generate_trip()` builds the plan and `app.py` sends it back as JSON.
4. `script.js` draws the plan on the page.
5. **Save trip** sends the same inputs plus a "seed" number. The server rebuilds the plan itself and stores it in SQLite, so the browser can never save fake data.

What changed in your `AITravelPlanner` class:
- Console `input()` menus became `validate_trip_request()` (web form checking).
- `get_weather()` no longer returns random numbers presented as weather.
- Activity prices (written as plain numbers) are treated as **INR** and converted to each destination's currency. Before, a "300" activity was added directly to EUR or JPY budgets, which was wrong.
- International activity prices are multiplied by `INTERNATIONAL_ACTIVITY_PRICE_FACTOR` (default 4) because the sample INR prices are too low for places like Paris. This is **my assumption**. Change it at the top of `travel_planner.py`, or set it to `1`.
- `generate_itinerary()` no longer shuffles your attraction lists in place and now avoids repeating attractions until all have been used.
- Display/printing methods were replaced by JSON output for the website.

---

## 7. Add or change data

Open `travel_planner.py`.
- **New destination:** add it to `self.destinations`, add a hotel entry in `self.hotels` (all three budget types), add a tip in `get_tip`, and add an entry in `DESTINATION_EXTRAS` near the top (latitude, longitude and the Wikipedia page title used for the photo).
- **Activities and restaurants:** edit `self.activities` and `self.restaurants`.
- **Exchange-rate fallback:** edit `FALLBACK_RATES_PER_INR`.
- **New currency:** add it to `CURRENCIES` and `FALLBACK_RATES_PER_INR`.

Restart the server after any change.

---

## 8. Upload the project to GitHub

**Step 1 – Install Git** from <https://git-scm.com/downloads> and check with `git --version`.

**Step 2 – Create an empty repository on GitHub**
Sign in at <https://github.com>, click **New repository**, name it `tripnova`, leave it empty
(do **not** add a README or .gitignore there), and click **Create repository**.

**Step 3 – Upload from your computer** (run in the project folder)
```
git init
git add .
git commit -m "Initial TripNova project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/tripnova.git
git push -u origin main
```
Replace `YOUR-USERNAME`. If asked to sign in, use your GitHub account (GitHub may ask for a personal access token instead of a password).

**Step 4 – Check before pushing:** run `git status`. You should **not** see `.env` or `tripnova.db` in the list. If you do, stop and check `.gitignore`.

**No Git?** On the repository page click **Add file → Upload files** and drag in the files and the `templates` and `static` folders. Do not upload `.env` or `.db` files.

---

## 9. Deploy online (Render)

Render can run Flask apps straight from GitHub. (Check Render's website for its current free-plan limits.)

1. Push the project to GitHub (section 8).
2. Create an account at <https://render.com> and choose **New → Web Service**.
3. Connect GitHub and select your `tripnova` repository.
4. Fill in:
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
5. Under **Environment Variables** add:
   - `SECRET_KEY` = a long random string (see section 3, step 5)
   - `COOKIE_SECURE` = `true`
   - `ANTHROPIC_API_KEY` = your key (only if you want the AI brief)
6. Click **Create Web Service**. After the build finishes, open the link Render gives you.

The `Procfile` (`web: gunicorn app:app`) makes the same project work on other hosts that use a Procfile (for example Railway or Heroku-style platforms). Add the same environment variables there.

### Important: SQLite and free hosting
SQLite stores data in a file. On many free hosting plans the disk is **temporary**, so accounts and saved trips can be **erased when the app redeploys or restarts**. For a college demo this is fine. For real use, either attach a persistent disk and set `DATABASE_PATH` to a path on it, or move to a hosted database such as PostgreSQL (this needs code changes in `app.py`).

`gunicorn` does not run on Windows. On your own computer, use `python app.py`.

---

## 10. Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: flask` | Activate the virtual environment, then run `pip install -r requirements.txt`. |
| "Cannot reach the server" on the page | The Flask app is not running. Start it with `python app.py`. |
| Destination photos are grey blue boxes | Photos load from Wikipedia and need internet. The site still works without them. |
| Weather shows "Seasonal estimate" | Normal for dates more than 15 days away, or if the forecast service is unreachable. |
| Costs say "approximate fixed rates" | The live exchange-rate service could not be reached. Estimates still work. |
| You get logged out after each restart (deployed) | `SECRET_KEY` is missing or changes. Set one fixed value. |
| AI button missing | `ANTHROPIC_API_KEY` is not set, or the trip is not saved yet (the AI brief works on saved trips). |
| Port 5000 already in use | Set `PORT=5001` in `.env` and open `http://127.0.0.1:5001`. |

---

## 11. Known limits (good to mention in your report)

- Hotel links come from your list. They are not checked automatically and prices are not live.
- Restaurant names are generic types, not specific venues. The page links each one to a Google Maps search.
- Costs are estimates from sample budgets, not live prices. Flights and visas are not included.
- The seasonal weather table is simple (four seasons for all places) and is not accurate for every climate, for example the southern hemisphere.
- Login protection is basic (password hashing, session cookies, a small login attempt limit). Add email verification, password reset and stronger rate limiting before real public use.

## 12. Credits

Destination photos are loaded from Wikipedia / Wikimedia Commons (each image has its own licence).
Weather forecasts: [Open-Meteo](https://open-meteo.com/). Exchange rates: [ExchangeRate-API open endpoint](https://www.exchangerate-api.com/).
Fonts: Poppins and Inter from Google Fonts.
